"""Komplexní testovací sada pro ověření šachových pravidel, šachu, šachmatu, patu a questů."""
import unittest
from models.game_manager import GameManager
from custom_pieces.kontrola_pohybu import KontrolaPohybu


class TestSachovnice(unittest.TestCase):
    def setUp(self):
        self.gm = GameManager()

    def test_tah_pesce(self):
        tahy = self.gm.revizor_tahu.mozne_tahy((6, 4))
        self.assertIn((4, 4), tahy)

    def test_op_stop(self):
        ok, _ = KontrolaPohybu.kontrola_op_stop("OP", [(1, 1)] * 20, "leaping", 1)
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
