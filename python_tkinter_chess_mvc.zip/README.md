# Šachy v Pythonu - Kompletní MVC Architektura (Tkinter)

Kompletní šachová aplikace v Pythonu vytvořená podle UML diagramů.

## Spuštění v PyCharmu:
1. Otevřete projekt v PyCharmu.
2. Spusťte: python main.py
3. Pro testy: python main.py --test
