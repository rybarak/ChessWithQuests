"""Informační panel hráče zobrazující časomíru, stav hry, vyhozené figurky a questy (HracView)."""
from typing import Any


class HracView:
    def __init__(self, rodic: Any, game_manager: Any):
        self.rodic = rodic
        self.game_manager = game_manager
        self.lbl_stav = None
        self.lbl_bily_cas = None
        self.lbl_cerny_cas = None
        self._vytvor_graficke_prvky()

    def _vytvor_graficke_prvky(self) -> None:
        try:
            import tkinter as tk
            from tkinter import ttk
        except ImportError:
            return

        frame = ttk.Frame(self.rodic, padding=12)
        frame.pack(fill=tk.BOTH, expand=True)

        self.lbl_stav = tk.Label(frame, text="Bílý na tahu", bg="#e0f2fe", font=("Helvetica", 11, "bold"), pady=8)
        self.lbl_stav.pack(fill=tk.X, pady=8)

        self.lbl_cerny_cas = tk.Label(frame, text="10:00", font=("Courier", 16, "bold"), bg="#1e293b", fg="#38bdf8")
        self.lbl_cerny_cas.pack(fill=tk.X, pady=4)

        self.lbl_bily_cas = tk.Label(frame, text="10:00", font=("Courier", 16, "bold"), bg="#15803d", fg="#ffffff")
        self.lbl_bily_cas.pack(fill=tk.X, pady=4)

    def aktualizuj_hrace(self) -> None:
        if not self.lbl_stav:
            return
        gm = self.game_manager
        self.lbl_stav.config(text=gm.get_stav())
        self.lbl_bily_cas.config(text=gm.casovac.formatovany_cas('b'))
        self.lbl_cerny_cas.config(text=gm.casovac.formatovany_cas('c'))
