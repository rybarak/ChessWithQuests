"""Grafické zobrazení šachovnice 8x8 v Tkinteru (GameView)."""
from typing import List, Tuple, Optional, Any


class GameView:
    def __init__(self, rodic: Any, plocha: Any, controller: Optional[Any] = None):
        self.rodic = rodic
        self.plocha = plocha
        self.controller = controller

        self.barva_svetla = "#f0d9b5"
        self.barva_tmava = "#b58863"
        self.barva_vyber = "#fef08a"       # Žlutá
        self.barva_pohyb = "#86efac"       # Zelená
        self.barva_utok = "#fca5a5"        # Červená

        self.policka: List[List[Any]] = [[None for _ in range(8)] for _ in range(8)]
        self._vytvor_graficke_prvky()

    def nastav_controller(self, controller: Any) -> None:
        self.controller = controller

    def _vytvor_graficke_prvky(self) -> None:
        try:
            import tkinter as tk
            from tkinter import font
        except ImportError:
            return

        ramec = tk.Frame(self.rodic, bd=4, relief=tk.RIDGE, bg="#4a3728")
        ramec.pack(padx=10, pady=10)
        pismo = font.Font(family="Arial Unicode MS", size=32, weight="bold")

        for r in range(8):
            for c in range(8):
                barva = self.barva_svetla if (r + c) % 2 == 0 else self.barva_tmava
                btn = tk.Button(
                    ramec, text="", font=pismo, bg=barva, relief=tk.FLAT, bd=0, width=3, height=1,
                    command=lambda row=r, col=c: self.controller.vyber_pole((row, col)) if self.controller else None
                )
                btn.grid(row=r, column=c)
                self.policka[r][c] = btn

        self.aktualizuj_plochu()

    def aktualizuj_plochu(self) -> None:
        for r in range(8):
            for c in range(8):
                f = self.plocha.vrat_obsah((r, c))
                btn = self.policka[r][c]
                if btn:
                    btn.config(text=f.symbol if f else "", fg="#0f172a" if f else "#000000")
        self.reset_stavu()

    def zobraz_mozne_tahy(self, tahy: List[Tuple[int, int]], vybrana_pozice: Optional[Tuple[int, int]] = None) -> None:
        self.reset_stavu()
        if vybrana_pozice and self.policka[vybrana_pozice[0]][vybrana_pozice[1]]:
            self.policka[vybrana_pozice[0]][vybrana_pozice[1]].config(bg=self.barva_vyber)

        for r, c in tahy:
            btn = self.policka[r][c]
            if btn:
                je_utok = self.plocha.vrat_obsah((r, c)) is not None
                btn.config(bg=self.barva_utok if je_utok else self.barva_pohyb)

    def reset_stavu(self) -> None:
        for r in range(8):
            for c in range(8):
                if self.policka[r][c]:
                    self.policka[r][c].config(bg=self.barva_svetla if (r + c) % 2 == 0 else self.barva_tmava)
