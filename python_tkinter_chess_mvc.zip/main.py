"""
Hlavní vstupní bod šachové aplikace v Pythonu s Tkinter rozhraním a MVC architekturou.

Spuštění v PyCharmu nebo terminálu:
    python main.py

Spuštění v headless testovacím režimu bez grafického serveru:
    python main.py --test
"""
import sys
import os

# Zajištění importu z kořenového adresáře
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.game_manager import GameManager
from models.herni_plocha import HerniPlocha
from users.uzivatel import Uzivatel
from users.hrac import Hrac
from users.user_manager import UserManager
from views.game_view import GameView
from views.hrac_view import HracView
from views.custom_piece_dialog import CustomPieceDialog
from controllers.game_manager_controller import GameManagerController


def spustit_gui():
    """Spustí plnohodnotné grafické okno Tkinter s MVC propojením."""
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog
    except ImportError:
        print("[CHYBA] Knihovna tkinter není nainstalována nebo není dostupný grafický displej.")
        print("Pro test herní logiky spusťte: python main.py --test")
        return

    root = tk.Tk()
    root.title("Python Tkinter Šachy - MVC Architektura")
    root.geometry("980x720")
    root.minsize(860, 640)

    # Inicializace správy uživatelů a výchozích hráčů
    user_mgr = UserManager()
    uziv_bily = user_mgr.najdi_uzivatele("bily_velmistr")
    uziv_cerny = user_mgr.najdi_uzivatele("cerny_vyzyvatel")

    hrac_b = Hrac('b', uziv_bily)
    hrac_c = Hrac('c', uziv_cerny)

    # 1. MODEL: GameManager
    game_manager = GameManager(hrac_bily=hrac_b, hrac_cerny=hrac_c, cas_na_partii=600)

    # Hlavní layout okna
    hlavni_kontejner = ttk.Frame(root)
    hlavni_kontejner.pack(fill=tk.BOTH, expand=True)

    # Horní lišta tlačítek
    lista_akci = ttk.Frame(hlavni_kontejner, padding=6)
    lista_akci.pack(fill=tk.X, side=tk.TOP)

    # 2. VIEW: Herní plocha vlevo
    plocha_kontejner = ttk.Frame(hlavni_kontejner)
    plocha_kontejner.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)

    game_view = GameView(rodic=plocha_kontejner, plocha=game_manager.plocha)

    # 3. VIEW: Informační panel hráčů vpravo
    panel_kontejner = ttk.Frame(hlavni_kontejner, width=320)
    panel_kontejner.pack(side=tk.RIGHT, fill=tk.BOTH, padx=10, pady=10)

    hrac_view = HracView(rodic=panel_kontejner, game_manager=game_manager)

    # 4. CONTROLLER: GameManagerController propojující Logiku a UI
    controller = GameManagerController(
        game_manager=game_manager,
        game_view=game_view,
        hrac_view=hrac_view
    )

    piece_dialog = CustomPieceDialog(root, game_manager, game_view)

    # Akce horní lišty
    def akce_nova_hra():
        if messagebox.askyesno("Nová hra", "Opravdu si přejete zahájit novou partii?"):
            controller.restartovat_partii()

    def akce_vytvorit_figurku():
        piece_dialog.otevri_editor()

    def akce_export_pgn():
        pgn = game_manager.exportuj_pgn()
        cesta = filedialog.asksaveasfilename(
            defaultextension=".pgn",
            filetypes=[("PGN soubory", "*.pgn"), ("Všechny soubory", "*.*")],
            title="Exportovat partii do PGN"
        )
        if cesta:
            with open(cesta, "w", encoding="utf-8") as f:
                f.write(pgn)
            messagebox.showinfo("Export dokončen", f"Partie byla uložena do:\n{cesta}")

    def akce_export_fen():
        fen = game_manager.exportuj_fen()
        root.clipboard_clear()
        root.clipboard_append(fen)
        messagebox.showinfo("FEN pozice", f"FEN byl zkopírován do schránky:\n\n{fen}")

    def akce_zobrazit_questy():
        kwesty = game_manager.quest_manager.kwesty
        text = "DOSTUPNÉ HERNÍ VÝZVY (QUESTY):\n\n"
        for q in kwesty:
            text += f"• {q.nazev} (+{q.odmena_elo} ELO)\n  {q.popis}\n\n"
        messagebox.showinfo("Přehled questů", text)

    ttk.Button(lista_akci, text="⟲ Nová hra", command=akce_nova_hra).pack(side=tk.LEFT, padx=4)
    ttk.Button(lista_akci, text="✪ Tvůrce figurky", command=akce_vytvorit_figurku).pack(side=tk.LEFT, padx=4)
    ttk.Button(lista_akci, text="📋 Zkopírovat FEN", command=akce_export_fen).pack(side=tk.LEFT, padx=4)
    ttk.Button(lista_akci, text="💾 Export PGN", command=akce_export_pgn).pack(side=tk.LEFT, padx=4)
    ttk.Button(lista_akci, text="🏆 Questy", command=akce_zobrazit_questy).pack(side=tk.LEFT, padx=4)

    # Tikání časovače každou sekundu
    def tik_casovace():
        if "mat" not in game_manager.stav_hry and "pat" not in game_manager.stav_hry:
            aktivni_barva = game_manager.aktivni_hrac.barva
            jeste_cas = game_manager.casovac.pocitej_cas(aktivni_barva, 1)
            if not jeste_cas:
                game_manager.stav_hry = f"cas_{aktivni_barva}"
                vitez = "Černý" if aktivni_barva == 'b' else "Bílý"
                game_manager.zprava_stavu = f"Čas vypršel! Vítězí {vitez}."
            hrac_view.aktualizuj_hrace()

        root.after(1000, tik_casovace)

    root.after(1000, tik_casovace)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        from tests.test_chess_suite import *
        import unittest
        unittest.main()
    else:
        spustit_gui()
