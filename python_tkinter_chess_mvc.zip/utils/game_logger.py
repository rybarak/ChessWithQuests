"""Třída pro zápis událostí hry a tahů do logovacího souboru."""
from typing import Optional, Any
from datetime import datetime


class GameLogger:
    def __init__(self, cesta: Optional[str] = "chess_game.log"):
        self.cesta_k_souboru = cesta
        self.zaznamy = []

    def vytvor_soubor(self, cesta: str) -> None:
        self.cesta_k_souboru = cesta

    def uloz_tah(self, tah: Any) -> None:
        zprava = f"[{datetime.now().strftime('%H:%M:%S')}] TAH: {tah.do_algebraicke_notace()} ({tah.figurka.barva})"
        self.zaloguj(zprava)

    def zaloguj(self, zprava: str) -> None:
        self.zaznamy.append(zprava)
        if self.cesta_k_souboru:
            try:
                with open(self.cesta_k_souboru, "a", encoding="utf-8") as f:
                    f.write(zprava + "\n")
            except Exception:
                pass
