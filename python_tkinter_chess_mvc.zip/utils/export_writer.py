"""Exportovací třídy pro šachový zápis (PGN, FEN, stenografický) a metadata."""
from datetime import datetime
from typing import List, Any


class ExportWriter:
    def __init__(self, field: str = "default_export"):
        self.field = field


class ChessNotationWriter(ExportWriter):
    def __init__(self):
        super().__init__(field="chess_notation")

    def get_pgn(self, historie_tahu: List[Any], bily_jmeno="Bílý", cerny_jmeno="Černý", vysledek="*") -> str:
        hlavicky = [
            f'[Event "Příležitostná šachová partie"]',
            f'[Site "Python Tkinter Chess"]',
            f'[Date "{datetime.now().strftime("%Y.%m.%d")}"]',
            f'[White "{bily_jmeno}"]',
            f'[Black "{cerny_jmeno}"]',
            f'[Result "{vysledek}"]'
        ]
        tahy = []
        for i, tah in enumerate(historie_tahu):
            if i % 2 == 0:
                tahy.append(f"{(i // 2) + 1}. {tah.do_algebraicke_notace()}")
            else:
                tahy.append(tah.do_algebraicke_notace())
        return "\n".join(hlavicky) + "\n\n" + " ".join(tahy)

    def get_fen(self, herni_deska: List[List[Any]], aktivni_barva='b') -> str:
        symbol_map = {"Pesak": ("P", "p"), "Vez": ("R", "r"), "Kun": ("N", "n"), "Strelec": ("B", "b"), "Dama": ("Q", "q"), "Kral": ("K", "k")}
        radky = []
        for r in range(8):
            prazdno, s = 0, ""
            for c in range(8):
                f = herni_deska[r][c]
                if f is None:
                    prazdno += 1
                else:
                    if prazdno > 0:
                        s += str(prazdno)
                        prazdno = 0
                    znaky = symbol_map.get(f.nazev, (f.nazev[:1].upper(), f.nazev[:1].lower()))
                    s += znaky[0] if f.je_bily else znaky[1]
            if prazdno > 0:
                s += str(prazdno)
            radky.append(s)
        return "/".join(radky) + f" {'w' if aktivni_barva == 'b' else 'b'} KQkq - 0 1"

    def Stenographic(self, historie_tahu: List[Any]) -> str:
        sloupce = "abcdefgh"
        return " ".join([f"{sloupce[t.vychozi_pozice[1]]}{8 - t.vychozi_pozice[0]}{sloupce[t.cilova_pozice[1]]}{8 - t.cilova_pozice[0]}" for t in historie_tahu])


class MetadataWriter(ExportWriter):
    def __init__(self):
        super().__init__(field="metadata")
