"""Časovač pro šachové hodiny obou hráčů."""
from typing import Dict, Optional


class Timer:
    def __init__(self, vychozi_cas_sekund: int = 600):
        self.vychozi_cas = vychozi_cas_sekund
        self.cas_hrac: Dict[str, int] = {'b': vychozi_cas_sekund, 'c': vychozi_cas_sekund}

    def nuluj_cas(self, novy_cas: Optional[int] = None) -> None:
        if novy_cas is not None:
            self.vychozi_cas = novy_cas
        self.cas_hrac['b'] = self.vychozi_cas
        self.cas_hrac['c'] = self.vychozi_cas

    def pocitej_cas(self, aktivni_barva: str, odecti_sekund: int = 1) -> bool:
        barva = 'b' if aktivni_barva.lower() in ('b', 'bily') else 'c'
        self.cas_hrac[barva] = max(0, self.cas_hrac[barva] - odecti_sekund)
        return self.cas_hrac[barva] > 0

    def formatovany_cas(self, barva: str) -> str:
        klic = 'b' if barva.lower() in ('b', 'bily') else 'c'
        sec = self.cas_hrac.get(klic, 0)
        return f"{sec // 60:02d}:{sec % 60:02d}"
