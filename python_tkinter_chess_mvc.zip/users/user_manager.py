"""Správa uživatelských profilů, registrace a historie odehraných partií."""
from typing import Dict, List, Optional
from users.uzivatel import Uzivatel


class UserManager:
    def __init__(self):
        self.id_uzivatele = 1
        self.log_uzivatelu: Dict[str, Uzivatel] = {}
        self.historie_uzivatele: Dict[str, List[dict]] = {}
        self._inicializuj()

    def _inicializuj(self):
        self.registruj_uzivatele(Uzivatel("bily_velmistr", "Bílý Velmistr", "white@chess.cz", elo=1350))
        self.registruj_uzivatele(Uzivatel("cerny_vyzyvatel", "Černý Vyzývatel", "black@chess.cz", elo=1320))

    def registruj_uzivatele(self, uzivatel: Uzivatel) -> Uzivatel:
        self.log_uzivatelu[uzivatel.uzivatelske_jmeno] = uzivatel
        self.historie_uzivatele[uzivatel.uzivatelske_jmeno] = []
        self.id_uzivatele += 1
        return uzivatel

    def najdi_uzivatele(self, uzivatelske_jmeno: str) -> Optional[Uzivatel]:
        return self.log_uzivatelu.get(uzivatelske_jmeno)
