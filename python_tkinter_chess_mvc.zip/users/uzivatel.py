"""Třída reprezentující registrovaného uživatele v systému."""
from typing import List, Optional


class Uzivatel:
    def __init__(
        self,
        uzivatelske_jmeno: str,
        jmeno: str,
        email: str,
        elo: int = 1200,
        splnene_kwesty: Optional[List[str]] = None
    ):
        self.uzivatelske_jmeno = uzivatelske_jmeno
        self.jmeno = jmeno
        self.email = email
        self.elo = elo
        self.splnene_kwesty = splnene_kwesty if splnene_kwesty is not None else []

    def pridej_quest(self, quest_nazev: str, odmena_elo: int = 0) -> None:
        if quest_nazev not in self.splnene_kwesty:
            self.splnene_kwesty.append(quest_nazev)
            self.elo += odmena_elo
