"""Systém herních výzev (questů) a jejich vyhodnocování."""
from typing import List, Callable, Any
from models.tah import Tah


class Quest:
    def __init__(self, id_questu: str, nazev: str, popis: str, odmena_elo: int, kontrola: Callable[[Tah, Any], bool]):
        self.id = id_questu
        self.nazev = nazev
        self.popis = popis
        self.odmena_elo = odmena_elo
        self.kontrola = kontrola

    def validate(self, tah: Tah, game_manager: Any) -> bool:
        try:
            return self.kontrola(tah, game_manager)
        except Exception:
            return False


class QuestManager:
    def __init__(self):
        self.kwesty: List[Quest] = [
            Quest("q_prvni_krev", "První krev", "Vyhoď figurku soupeře", 15, lambda t, gm: t.vyhozena_figurka is not None),
            Quest("q_jezdcuv_vypad", "Jezdcův výpad", "Zahraj tah koněm", 10, lambda t, gm: t.figurka.nazev == "Kun"),
            Quest("q_rosada", "Královská pevnost", "Proveď rošádu", 20, lambda t, gm: t.typ_tahu == "rosada"),
            Quest("q_sach", "Ohrožení panovníka", "Dej soupeři šach", 25, lambda t, gm: gm.revizor_tahu.check_Sach('c' if t.figurka.je_bily else 'b')),
            Quest("q_mat", "Matový úder", "Ukonči partii šachmatem", 100, lambda t, gm: gm.revizor_tahu.check_Mat('c' if t.figurka.je_bily else 'b'))
        ]

    def vyhodnot_kwesty(self, hrac: Any, tah: Tah, game_manager: Any) -> List[Quest]:
        splnene = []
        for q in self.kwesty:
            if q.nazev not in hrac.uzivatel.splnene_kwesty and q.validate(tah, game_manager):
                hrac.uzivatel.pridej_quest(q.nazev, q.odmena_elo)
                splnene.append(q)
        return splnene
