"""Třída reprezentující hráče v konkrétní šachové partii."""
from users.uzivatel import Uzivatel


class Hrac:
    def __init__(self, barva: str, uzivatel: Uzivatel):
        self.barva = barva.lower()
        self.uzivatel = uzivatel

    def getEloRating(self) -> int:
        return self.uzivatel.elo
