"""Třída pro šachovou figurku Král."""
from models.figurka import Figurka


class Kral(Figurka):
    """Král - pohybuje se o 1 pole v jakémkoli z 8 směrů."""

    def __init__(self, barva: str):
        symbol = "♔" if barva.lower() in ('b', 'bily', 'white') else "♚"

        vsechny_smery = [
            (-1, -1), (-1, 0), (-1, 1),
            (0, -1),           (0, 1),
            (1, -1),  (1, 0),  (1, 1)
        ]

        super().__init__(
            nazev="Kral",
            barva=barva,
            vektory=vsechny_smery,
            vektory_utoku=vsechny_smery,
            skok=False,
            hodnota=1000,
            symbol=symbol
        )
