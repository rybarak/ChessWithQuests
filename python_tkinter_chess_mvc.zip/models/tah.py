"""Třída reprezentující herní tah na šachovnici."""
from typing import Tuple, Optional, Any


class Tah:
    def __init__(
        self,
        vychozi_pozice: Tuple[int, int],
        cilova_pozice: Tuple[int, int],
        figurka: Any,
        typ_tahu: str = "pohyb",
        vyhozena_figurka: Optional[Any] = None,
        promena_na: Optional[Any] = None
    ):
        self.vychozi_pozice = vychozi_pozice
        self.cilova_pozice = cilova_pozice
        self.figurka = figurka
        self.typ_tahu = typ_tahu
        self.vyhozena_figurka = vyhozena_figurka
        self.promena_na = promena_na

    def over_platnost(self) -> bool:
        r1, c1 = self.vychozi_pozice
        r2, c2 = self.cilova_pozice
        if not (0 <= r1 < 8 and 0 <= c1 < 8 and 0 <= r2 < 8 and 0 <= c2 < 8):
            return False
        return (r1, c1) != (r2, c2) and self.figurka is not None

    def proved_tah(self, herni_plocha: Any) -> bool:
        return herni_plocha.posun_figurky(self)

    def do_algebraicke_notace(self) -> str:
        sloupce = "abcdefgh"
        r1, c1 = self.vychozi_pozice
        r2, c2 = self.cilova_pozice
        cil_pole = f"{sloupce[c2]}{8 - r2}"

        if self.figurka.nazev == "Pesak":
            if self.typ_tahu in ("brani", "en_passant"):
                return f"{sloupce[c1]}x{cil_pole}"
            return cil_pole

        prefixy = {"Kun": "N", "Strelec": "B", "Vez": "R", "Dama": "Q", "Kral": "K"}
        pref = prefixy.get(self.figurka.nazev, self.figurka.nazev[:1].upper())
        sep = "x" if self.typ_tahu in ("brani", "en_passant") else ""

        if self.typ_tahu == "rosada":
            return "O-O" if c2 > c1 else "O-O-O"

        return f"{pref}{sep}{cil_pole}"
