"""Herní matematika a ověřování pravidel šachů."""
from typing import List, Tuple, Union, Any
from models.figurka import Figurka
from models.pesak import Pesak
from models.kral import Kral
from models.tah import Tah


class RevizorTahu:
    """Ověřování tahů, detekce šachu, matu a patu."""

    def __init__(self, plocha: Any):
        self.plocha = plocha

    def mozne_tahy(self, vstup: Union[Tuple[int, int], Figurka]) -> List[Tuple[int, int]]:
        if isinstance(vstup, tuple):
            souradnice = vstup
            figurka = self.plocha.vrat_obsah(souradnice)
        else:
            figurka = vstup
            souradnice = next(
                ((r, c) for r in range(8) for c in range(8) if self.plocha.herni_deska[r][c] is figurka),
                None
            )

        if figurka is None or souradnice is None:
            return []

        pseudolegalni = self.generuj_pseudolegalni_tahy(souradnice)
        return [
            cil for cil in pseudolegalni
            if not self.simulate_Move(Tah(souradnice, cil, figurka))
        ]

    def generuj_pseudolegalni_tahy(self, souradnice: Tuple[int, int]) -> List[Tuple[int, int]]:
        figurka = self.plocha.vrat_obsah(souradnice)
        if figurka is None:
            return []

        r, c = souradnice
        barva = figurka.barva
        mozne = []

        if isinstance(figurka, Pesak):
            smer = figurka.smer
            if self.plocha.je_v_mezich((r + smer, c)) and self.plocha.vrat_obsah((r + smer, c)) is None:
                mozne.append((r + smer, c))
                start_r = 6 if figurka.je_bily else 1
                if r == start_r and self.plocha.vrat_obsah((r + 2 * smer, c)) is None:
                    mozne.append((r + 2 * smer, c))

            for dc in (-1, 1):
                rc = (r + smer, c + dc)
                if self.plocha.je_v_mezich(rc):
                    cil = self.plocha.vrat_obsah(rc)
                    if cil is not None and cil.barva != barva:
                        mozne.append(rc)
            return mozne

        if figurka.skok:
            for dr, dc in figurka.vektory:
                rc = (r + dr, c + dc)
                if self.plocha.je_v_mezich(rc):
                    cil = self.plocha.vrat_obsah(rc)
                    if cil is None or cil.barva != barva:
                        mozne.append(rc)
            return mozne

        if isinstance(figurka, Kral):
            for dr, dc in figurka.vektory:
                rc = (r + dr, c + dc)
                if self.plocha.je_v_mezich(rc):
                    cil = self.plocha.vrat_obsah(rc)
                    if cil is None or cil.barva != barva:
                        mozne.append(rc)
            return mozne

        for dr, dc in figurka.vektory:
            krok = 1
            while True:
                rc = (r + dr * krok, c + dc * krok)
                if not self.plocha.je_v_mezich(rc):
                    break
                cil = self.plocha.vrat_obsah(rc)
                if cil is None:
                    mozne.append(rc)
                else:
                    if cil.barva != barva:
                        mozne.append(rc)
                    break
                krok += 1

        return mozne

    def je_pole_ohrozeno(self, souradnice: Tuple[int, int], barva_obrance: str) -> bool:
        souper_barva = 'c' if barva_obrance.lower() in ('b', 'bily') else 'b'
        for (fr, fc), figurka in self.plocha.ziskej_vsechny_figurky(souper_barva):
            if isinstance(figurka, Pesak):
                for dr, dc in figurka.vektory_utoku:
                    if (fr + dr, fc + dc) == souradnice:
                        return True
            elif figurka.skok or isinstance(figurka, Kral):
                for dr, dc in figurka.vektory:
                    if (fr + dr, fc + dc) == souradnice:
                        return True
            else:
                for dr, dc in figurka.vektory:
                    krok = 1
                    while True:
                        rc = (fr + dr * krok, fc + dc * krok)
                        if not self.plocha.je_v_mezich(rc):
                            break
                        if rc == souradnice:
                            return True
                        if self.plocha.vrat_obsah(rc) is not None:
                            break
                        krok += 1
        return False

    def simulate_Move(self, tah: Tah) -> bool:
        sim_plocha = self.plocha.kopie()
        sim_revizor = RevizorTahu(sim_plocha)
        sim_tah = Tah(tah.vychozi_pozice, tah.cilova_pozice, sim_plocha.vrat_obsah(tah.vychozi_pozice))
        sim_plocha.posun_figurky(sim_tah)
        return sim_revizor.check_Sach(tah.figurka.barva)

    def check_Sach(self, barva: str) -> bool:
        pozice_krala = self.plocha.najdi_krala(barva)
        return self.je_pole_ohrozeno(pozice_krala, barva) if pozice_krala else False

    def ma_hrac_legalni_tahy(self, barva: str) -> bool:
        return any(len(self.mozne_tahy(pos)) > 0 for pos, _ in self.plocha.ziskej_vsechny_figurky(barva))

    def check_Mat(self, barva: str) -> bool:
        return self.check_Sach(barva) and not self.ma_hrac_legalni_tahy(barva)

    def check_Pat(self, barva: str) -> bool:
        return not self.check_Sach(barva) and not self.ma_hrac_legalni_tahy(barva)
