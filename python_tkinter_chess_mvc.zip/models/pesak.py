"""Třída pro šachovou figurku Pěšák."""
from models.figurka import Figurka


class Pesak(Figurka):
    """
    Pěšák - pohybuje se dopředu o 1 pole (při 1. tahu o 2 pole),
    bere soupeřovy figurky diagonálně o 1 pole.
    Směr pohybu:
        - bílý: -1 (směrem nahoru po desce, z řádku 6 na 0)
        - černý: +1 (směrem dolů po desce, z řádku 1 na 7)
    """

    def __init__(self, barva: str):
        smer = -1 if barva.lower() in ('b', 'bily', 'white') else 1
        symbol = "♙" if barva.lower() in ('b', 'bily', 'white') else "♟"

        vektory = [(smer, 0)]
        vektory_utoku = [(smer, -1), (smer, 1)]

        super().__init__(
            nazev="Pesak",
            barva=barva,
            vektory=vektory,
            vektory_utoku=vektory_utoku,
            skok=False,
            hodnota=1,
            symbol=symbol
        )
        self.smer = smer
        self.en_passant_zranitelny = False
