"""Základní bázová třída pro šachové figurky."""
from typing import List, Tuple, Optional


class Figurka:
    """
    Abstraktní bázová třída reprezentující šachovou figurku.

    Atributy:
        nazev (str): Název figurky (např. 'Pěšák', 'Jezdec', 'Dáma')
        barva (str): Barva figurky ('b' pro bílý, 'c' pro černý)
        vektory (List[Tuple[int, int]]): Směrové vektory pro pohyb
        vektory_utoku (List[Tuple[int, int]]): Směrové vektory pro útok/braní
        skok (bool): Zda figurka může přeskakovat ostatní figurky (např. Kůň)
        hodnota (int): Standardní materiální hodnota figurky
        symbol (str): Unicode znak pro grafické znázornění
        pocet_tahu (int): Počet realizovaných tahů figurkou
    """

    def __init__(
        self,
        nazev: str,
        barva: str,
        vektory: Optional[List[Tuple[int, int]]] = None,
        vektory_utoku: Optional[List[Tuple[int, int]]] = None,
        skok: bool = False,
        hodnota: int = 1,
        symbol: str = "?"
    ):
        self.nazev = nazev
        self.barva = barva.lower()
        self.vektory = vektory if vektory is not None else []
        self.vektory_utoku = vektory_utoku if vektory_utoku is not None else list(self.vektory)
        self.skok = skok
        self.hodnota = hodnota
        self.symbol = symbol
        self.pocet_tahu = 0

    @property
    def je_bily(self) -> bool:
        return self.barva in ('b', 'bily', 'white')

    @property
    def je_cerny(self) -> bool:
        return self.barva in ('c', 'cerny', 'black')

    def zaznamenej_tah(self) -> None:
        self.pocet_tahu += 1

    def vrat_symbol(self) -> str:
        return self.symbol

    def __repr__(self) -> str:
        return f"{self.nazev}({self.barva})"
