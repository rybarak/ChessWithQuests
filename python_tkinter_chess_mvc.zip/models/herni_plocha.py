"""Třída reprezentující šachovnici 8x8 a stav na ní."""
from typing import List, Tuple, Optional, Any
import copy

from models.figurka import Figurka
from models.pesak import Pesak
from models.vez import Vez
from models.kun import Kun
from models.strelec import Strelec
from models.dama import Dama
from models.kral import Kral


class HerniPlocha:
    """
    Správa stavu šachovnice 8x8, umístění figurek a vyhozených figurek.
    """

    def __init__(self, rozmery: Tuple[int, int] = (8, 8)):
        self.rozmery = rozmery
        self.herni_deska: List[List[Optional[Figurka]]] = [
            [None for _ in range(self.rozmery[1])]
            for _ in range(self.rozmery[0])
        ]
        self.vyhozene_figurky_b: List[Figurka] = []
        self.vyhozene_figurky_c: List[Figurka] = []
        self.posledni_tah: Optional[Any] = None
        self.inicializuj_zakladni_postaveni()

    def inicializuj_zakladni_postaveni(self) -> None:
        for r in range(8):
            for c in range(8):
                self.herni_deska[r][c] = None

        self.vyhozene_figurky_b.clear()
        self.vyhozene_figurky_c.clear()

        # Černé figurky (horní strana)
        self.herni_deska[0][0] = Vez('c')
        self.herni_deska[0][1] = Kun('c')
        self.herni_deska[0][2] = Strelec('c')
        self.herni_deska[0][3] = Dama('c')
        self.herni_deska[0][4] = Kral('c')
        self.herni_deska[0][5] = Strelec('c')
        self.herni_deska[0][6] = Kun('c')
        self.herni_deska[0][7] = Vez('c')
        for c in range(8):
            self.herni_deska[1][c] = Pesak('c')

        # Bílé figurky (dolní strana)
        for c in range(8):
            self.herni_deska[6][c] = Pesak('b')
        self.herni_deska[7][0] = Vez('b')
        self.herni_deska[7][1] = Kun('b')
        self.herni_deska[7][2] = Strelec('b')
        self.herni_deska[7][3] = Dama('b')
        self.herni_deska[7][4] = Kral('b')
        self.herni_deska[7][5] = Strelec('b')
        self.herni_deska[7][6] = Kun('b')
        self.herni_deska[7][7] = Vez('b')

    def je_v_mezich(self, souradnice: Tuple[int, int]) -> bool:
        r, c = souradnice
        return 0 <= r < self.rozmery[0] and 0 <= c < self.rozmery[1]

    def vrat_obsah(self, souradnice: Tuple[int, int]) -> Optional[Figurka]:
        if not self.je_v_mezich(souradnice):
            return None
        r, c = souradnice
        return self.herni_deska[r][c]

    def posun_figurky(self, tah: Any) -> bool:
        if not tah.over_platnost():
            return False

        r1, c1 = tah.vychozi_pozice
        r2, c2 = tah.cilova_pozice
        figurka = self.herni_deska[r1][c1]

        if figurka is None:
            return False

        cilovy_obsah = self.herni_deska[r2][c2]

        if cilovy_obsah is not None:
            tah.vyhozena_figurka = cilovy_obsah
            if cilovy_obsah.je_bily:
                self.vyhozene_figurky_b.append(cilovy_obsah)
            else:
                self.vyhozene_figurky_c.append(cilovy_obsah)
            tah.typ_tahu = "brani"

        # Rošáda
        if isinstance(figurka, Kral) and abs(c2 - c1) == 2:
            tah.typ_tahu = "rosada"
            if c2 > c1:
                vez = self.herni_deska[r1][7]
                self.herni_deska[r1][7] = None
                self.herni_deska[r1][5] = vez
            else:
                vez = self.herni_deska[r1][0]
                self.herni_deska[r1][0] = None
                self.herni_deska[r1][3] = vez

        self.herni_deska[r2][c2] = figurka
        self.herni_deska[r1][c1] = None
        figurka.zaznamenej_tah()

        # Proměna pěšce
        if isinstance(figurka, Pesak):
            posledni_radek = 0 if figurka.je_bily else 7
            if r2 == posledni_radek:
                nova_figurka = tah.promena_na if tah.promena_na is not None else Dama(figurka.barva)
                self.nahrad_figurku(nova_figurka, tah)
                tah.typ_tahu = "promena"

        self.posledni_tah = tah
        return True

    def nahrad_figurku(self, nova_figurka: Figurka, tah: Any) -> None:
        r2, c2 = tah.cilova_pozice
        self.herni_deska[r2][c2] = nova_figurka

    def najdi_krala(self, barva: str) -> Optional[Tuple[int, int]]:
        cilova_barva = 'b' if barva.lower() in ('b', 'bily') else 'c'
        for r in range(self.rozmery[0]):
            for c in range(self.rozmery[1]):
                f = self.herni_deska[r][c]
                if f is not None and isinstance(f, Kral) and f.barva == cilova_barva:
                    return (r, c)
        return None

    def ziskej_vsechny_figurky(self, barva: Optional[str] = None) -> List[Tuple[Tuple[int, int], Figurka]]:
        vysledek = []
        cilova_barva = ('b' if barva.lower() in ('b', 'bily') else 'c') if barva else None
        for r in range(self.rozmery[0]):
            for c in range(self.rozmery[1]):
                f = self.herni_deska[r][c]
                if f is not None and (cilova_barva is None or f.barva == cilova_barva):
                    vysledek.append(((r, c), f))
        return vysledek

    def kopie(self) -> "HerniPlocha":
        nova = HerniPlocha.__new__(HerniPlocha)
        nova.rozmery = self.rozmery
        nova.herni_deska = [
            [copy.copy(self.herni_deska[r][c]) for c in range(self.rozmery[1])]
            for r in range(self.rozmery[0])
        ]
        nova.vyhozene_figurky_b = list(self.vyhozene_figurky_b)
        nova.vyhozene_figurky_c = list(self.vyhozene_figurky_c)
        nova.posledni_tah = copy.copy(self.posledni_tah) if self.posledni_tah else None
        return nova
