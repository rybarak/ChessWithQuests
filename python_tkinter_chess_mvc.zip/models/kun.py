"""Třída pro šachovou figurku Kůň / Jezdec."""
from models.figurka import Figurka


class Kun(Figurka):
    """
    Kůň (Jezdec) - pohybuje se do tvaru písmene 'L'.
    Může přeskakovat ostatní figurky (skok = True).
    """

    def __init__(self, barva: str):
        symbol = "♘" if barva.lower() in ('b', 'bily', 'white') else "♞"

        l_vektory = [
            (-2, -1), (-2, 1),
            (-1, -2), (-1, 2),
            (1, -2),  (1, 2),
            (2, -1),  (2, 1)
        ]

        super().__init__(
            nazev="Kun",
            barva=barva,
            vektory=l_vektory,
            vektory_utoku=l_vektory,
            skok=True,
            hodnota=3,
            symbol=symbol
        )
