"""Třída pro šachovou figurku Věž."""
from models.figurka import Figurka


class Vez(Figurka):
    """Věž - pohybuje se po sloupcích a řádcích (ortogonálně)."""

    def __init__(self, barva: str):
        symbol = "♖" if barva.lower() in ('b', 'bily', 'white') else "♜"

        prime_smery = [
            (-1, 0), (1, 0),
            (0, -1), (0, 1)
        ]

        super().__init__(
            nazev="Vez",
            barva=barva,
            vektory=prime_smery,
            vektory_utoku=prime_smery,
            skok=False,
            hodnota=5,
            symbol=symbol
        )
