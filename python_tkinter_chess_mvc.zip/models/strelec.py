"""Třída pro šachovou figurku Střelec."""
from models.figurka import Figurka


class Strelec(Figurka):
    """Střelec - pohybuje se po diagonálách na libovolnou vzdálenost."""

    def __init__(self, barva: str):
        symbol = "♗" if barva.lower() in ('b', 'bily', 'white') else "♝"

        diagonaly = [
            (-1, -1), (-1, 1),
            (1, -1),  (1, 1)
        ]

        super().__init__(
            nazev="Strelec",
            barva=barva,
            vektory=diagonaly,
            vektory_utoku=diagonaly,
            skok=False,
            hodnota=3,
            symbol=symbol
        )
