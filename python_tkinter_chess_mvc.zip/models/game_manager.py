"""Centrální herní manažer koordinující pravidla, hráče, časomíru a průběh partie."""
from typing import Dict, List, Tuple, Optional, Any
from models.herni_plocha import HerniPlocha
from models.revizor_tahu import RevizorTahu
from models.figurka import Figurka
from models.tah import Tah
from users.hrac import Hrac
from users.uzivatel import Uzivatel
from users.quest import QuestManager
from utils.game_logger import GameLogger
from utils.timer import Timer
from utils.export_writer import ChessNotationWriter, MetadataWriter


class GameManager:
    def __init__(self, hrac_bily: Optional[Hrac] = None, hrac_cerny: Optional[Hrac] = None, cas_na_partii: int = 600):
        self.plocha = HerniPlocha()
        self.revizor_tahu = RevizorTahu(self.plocha)
        self.quest_manager = QuestManager()
        self.casovac = Timer(vychozi_cas_sekund=cas_na_partii)
        self.game_logger = GameLogger("chess_game.log")
        self.notation_writer = ChessNotationWriter()
        self.metadata_writer = MetadataWriter()

        if hrac_bily is None:
            hrac_bily = Hrac('b', Uzivatel("bily_hrac", "Bílý Hráč", "bily@chess.cz", elo=1250))
        if hrac_cerny is None:
            hrac_cerny = Hrac('c', Uzivatel("cerny_hrac", "Černý Hráč", "cerny@chess.cz", elo=1250))

        self.hraci: Dict[str, Hrac] = {'b': hrac_bily, 'c': hrac_cerny}
        self.aktivni_hrac: Hrac = self.hraci['b']
        self.aktualni_tah: Optional[Tah] = None
        self.aktivni_figurka: Optional[Figurka] = None
        self.aktivni_pozice: Optional[Tuple[int, int]] = None
        self.historie_tahu: List[Tah] = []
        self.stav_hry: str = "hraje_bily"
        self.zprava_stavu: str = "Bílý na tahu"

    def je_vlastni_figurka(self, souradnice: Tuple[int, int]) -> bool:
        f = self.plocha.vrat_obsah(souradnice)
        return f is not None and f.barva == self.aktivni_hrac.barva

    def nastav_aktivni_figurku(self, figurka: Figurka, souradnice: Tuple[int, int]) -> None:
        self.aktivni_figurka = figurka
        self.aktivni_pozice = souradnice

    def zrus_tah(self) -> None:
        self.aktivni_figurka = None
        self.aktivni_pozice = None

    def mozne_tahy(self, souradnice: Optional[Tuple[int, int]] = None) -> List[Tuple[int, int]]:
        pos = souradnice or self.aktivni_pozice
        return self.revizor_tahu.mozne_tahy(pos) if pos else []

    def proved_tah(self, cilove_souradnice: Tuple[int, int]) -> bool:
        if self.aktivni_pozice is None or self.aktivni_figurka is None:
            return False

        if cilove_souradnice not in self.mozne_tahy(self.aktivni_pozice):
            return False

        tah = Tah(self.aktivni_pozice, cilove_souradnice, self.aktivni_figurka)
        if not self.plocha.posun_figurky(tah):
            return False

        self.historie_tahu.append(tah)
        self.aktualni_tah = tah
        self.game_logger.uloz_tah(tah)

        self.quest_manager.vyhodnot_kwesty(self.aktivni_hrac, tah, self)
        self.zmen_hrace()
        self.aktualizuj_stav_hry()
        self.zrus_tah()
        return True

    def zmen_hrace(self) -> None:
        self.aktivni_hrac = self.hraci['c' if self.aktivni_hrac.barva == 'b' else 'b']

    def aktualizuj_stav_hry(self) -> None:
        barva = self.aktivni_hrac.barva
        if self.revizor_tahu.check_Mat(barva):
            vitez = "Černý" if barva == 'b' else "Bílý"
            self.stav_hry = f"mat_{barva}"
            self.zprava_stavu = f"ŠACHMAT! Vítězí {vitez}!"
        elif self.revizor_tahu.check_Pat(barva):
            self.stav_hry = "remiza_pat"
            self.zprava_stavu = "PAT! Hra končí remízou."
        elif self.revizor_tahu.check_Sach(barva):
            self.stav_hry = f"sach_{barva}"
            self.zprava_stavu = f"ŠACH pro hráče {'Bílý' if barva == 'b' else 'Černý'}!"
        else:
            self.stav_hry = f"hraje_{barva}"
            self.zprava_stavu = f"{'Bílý' if barva == 'b' else 'Černý'} na tahu"

    def get_stav(self) -> str:
        return self.zprava_stavu

    def exportuj_pgn(self) -> str:
        return self.notation_writer.get_pgn(
            self.historie_tahu,
            self.hraci['b'].uzivatel.jmeno,
            self.hraci['c'].uzivatel.jmeno
        )

    def exportuj_fen(self) -> str:
        return self.notation_writer.get_fen(self.plocha.herni_deska, self.aktivni_hrac.barva)
