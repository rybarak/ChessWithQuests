"""Třída pro šachovou figurku Dáma (Královna)."""
from models.figurka import Figurka


class Dama(Figurka):
    """Dáma - kombinuje pohyb Věže i Střelce (8 směrů na libovolnou vzdálenost)."""

    def __init__(self, barva: str):
        symbol = "♕" if barva.lower() in ('b', 'bily', 'white') else "♛"

        vsechny_smery = [
            (-1, 0), (1, 0), (0, -1), (0, 1),
            (-1, -1), (-1, 1), (1, -1), (1, 1)
        ]

        super().__init__(
            nazev="Dama",
            barva=barva,
            vektory=vsechny_smery,
            vektory_utoku=vsechny_smery,
            skok=False,
            hodnota=9,
            symbol=symbol
        )
