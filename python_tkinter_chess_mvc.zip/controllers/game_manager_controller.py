"""MVC Kontrolér propojující logiku herního manažera s uživatelským rozhraním Tkinter."""
from typing import Tuple, Optional, Any


class GameManagerController:
    """
    Řídící kontrolér dle sekvenčního diagramu.
    """

    def __init__(self, game_manager: Any, game_view: Any, hrac_view: Optional[Any] = None):
        self.game_manager = game_manager
        self.game_view = game_view
        self.hrac_view = hrac_view
        if self.game_view:
            self.game_view.nastav_controller(self)

    def vyber_pole(self, souradnice: Tuple[int, int]) -> None:
        """
        Klíčová metoda sekvenčního diagramu:
        1. Zkontroluje přes GameManager je_vlastni_figurka.
        2. Získá figurku přes vrat_obsah.
        3. Nastaví ji jako aktivní (nastav_aktivni_figurku).
        4. Přes RevizorTahu získá mozne_tahy.
        5. Pošle je do GameView k vykreslení (zobraz_mozne_tahy).
        6. Při 2. kliknutí provede tah přes proved_tah() a aktualizuje obě views.
        """
        gm = self.game_manager

        if "mat" in gm.stav_hry or "pat" in gm.stav_hry:
            return

        if gm.aktivni_figurka is not None and gm.aktivni_pozice is not None:
            mozne_cile = gm.mozne_tahy(gm.aktivni_pozice)
            if souradnice in mozne_cile:
                if gm.proved_tah(souradnice):
                    self.game_view.aktualizuj_plochu()
                    if self.hrac_view:
                        self.hrac_view.aktualizuj_hrace()
                    return

            if gm.je_vlastni_figurka(souradnice):
                self._aktivuj_figurku(souradnice)
                return

            gm.zrus_tah()
            self.game_view.reset_stavu()
            return

        if gm.je_vlastni_figurka(souradnice):
            self._aktivuj_figurku(souradnice)
        else:
            gm.zrus_tah()
            self.game_view.reset_stavu()

    def _aktivuj_figurku(self, souradnice: Tuple[int, int]) -> None:
        gm = self.game_manager
        f = gm.plocha.vrat_obsah(souradnice)
        if f:
            gm.nastav_aktivni_figurku(f, souradnice)
            tahy = gm.mozne_tahy(souradnice)
            self.game_view.zobraz_mozne_tahy(tahy, vybrana_pozice=souradnice)

    def restartovat_partii(self) -> None:
        gm = self.game_manager
        gm.plocha.inicializuj_zakladni_postaveni()
        gm.aktivni_hrac = gm.hraci['b']
        gm.zacni_tah()
        gm.historie_tahu.clear()
        gm.casovac.nuluj_cas()
        gm.aktualizuj_stav_hry()
        self.game_view.aktualizuj_plochu()
        if self.hrac_view:
            self.hrac_view.aktualizuj_hrace()
