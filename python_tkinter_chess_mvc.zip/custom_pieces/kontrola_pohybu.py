"""Kontrola validity pohybových vektorů a OP (Overpowered) Stop mechanismus."""
from typing import List, Tuple


class KontrolaPohybu:
    @classmethod
    def kontrola_op_stop(cls, nazev: str, vektory: List[Tuple[int, int]], typ_pohybu: str, max_kroku: int) -> Tuple[bool, str]:
        if not vektory:
            return False, "Figurka musí mít alespoň jeden vektor."
        if typ_pohybu == "leaping":
            if len(vektory) > 10:
                return False, f"OP STOP aktivován! Skákající figurka má {len(vektory)} skoků (max 10)."
            for dr, dc in vektory:
                if abs(dr) > 4 or abs(dc) > 4:
                    return False, f"OP STOP! Skok ({dr}, {dc}) překračuje max dosah 4 polí."
        elif typ_pohybu == "sliding" and len(vektory) > 8:
            return False, "OP STOP! Klouzavá figurka nesmí mít víc než 8 směrů."
        return True, "Validace úspěšná: Figurka je vyvážená."
