"""Uložiště pro perzistenci vlastních figurek do souboru JSON."""
import json
import os
from custom_pieces.vlastni_figurka import VlastniFigurka


class Uloziste:
    def __init__(self, soubor: str = "custom_pieces.json"):
        self.soubor = soubor

    def uloz_figurku(self, figurka: VlastniFigurka) -> bool:
        vse = self.nacti_vsechny()
        vse = [f for f in vse if f.get("nazev") != figurka.nazev]
        vse.append(figurka.to_dict())
        try:
            with open(self.soubor, "w", encoding="utf-8") as f:
                json.dump(vse, f, indent=2, ensure_ascii=False)
            return True
        except Exception:
            return False

    def nacti_vsechny(self):
        if not os.path.exists(self.soubor):
            return []
        try:
            with open(self.soubor, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
