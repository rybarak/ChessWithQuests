"""Třída pro dynamicky vytvořené uživatelské šachové figurky."""
from typing import List, Tuple, Optional
from models.figurka import Figurka


class VlastniFigurka(Figurka):
    def __init__(
        self,
        nazev: str,
        barva: str,
        symbol: str = "✪",
        typ_pohybu: str = "stepping",
        vektory: Optional[List[Tuple[int, int]]] = None,
        max_kroku: int = 1,
        hodnota: int = 4
    ):
        super().__init__(
            nazev=nazev,
            barva=barva,
            vektory=vektory or [(1, 1), (-1, -1)],
            skok=(typ_pohybu == "leaping"),
            hodnota=hodnota,
            symbol=symbol
        )
        self.typ_pohybu = typ_pohybu
        self.max_kroku = max_kroku
