"""Manažer procesu tvorby vlastních figurek, propojující validaci a perzistenci."""
from custom_pieces.vlastni_figurka import VlastniFigurka
from custom_pieces.kontrola_pohybu import KontrolaPohybu
from custom_pieces.uloziste import Uloziste


class SpravceTvorby:
    def __init__(self, uloziste=None):
        self.uloziste = uloziste or Uloziste()

    def vytvor_figurku(self, nazev, barva, symbol, typ_pohybu, vektory, max_kroku=1, hodnota=4):
        ok, msg = KontrolaPohybu.kontrola_op_stop(nazev, vektory, typ_pohybu, max_kroku)
        if not ok:
            return None, msg

        f = VlastniFigurka(nazev, barva, symbol, typ_pohybu, vektory, max_kroku, hodnota)
        self.uloziste.uloz_figurku(f)
        return f, f"Figurka '{nazev}' byla úspěšně vytvořena a uložena!"
