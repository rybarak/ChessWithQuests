"""Uživatelské rozhraní pro tvorbu a konfiguraci vlastních šachových figurek v Tkinteru."""
from custom_pieces.spravce_tvorby import SpravceTvorby


class RozhraniTvurce:
    def __init__(self, rodic=None, callback_ulozeni=None):
        self.rodic = rodic
        self.callback_ulozeni = callback_ulozeni
        self.spravce = SpravceTvorby()

    def zobraz(self):
        try:
            import tkinter as tk
            from tkinter import ttk, messagebox
        except ImportError:
            return
        # Okno Tkinter pro zadání parametrů figurky
